--EPISODE
--0House of Cards
INSERT INTO EPISODE VALUES(20,'0-AA',1,'House of Cards Season1',1);
INSERT INTO EPISODE VALUES(20,'0-BB',2,'House of Cards Season1',1);
INSERT INTO EPISODE VALUES(20,'0-CC',3,'House of Cards Season1',1);
INSERT INTO EPISODE VALUES(20,'0-DD',4,'House of Cards Season1',1);
INSERT INTO EPISODE VALUES(20,'0-EE',5,'House of Cards Season1',1);

--1 Orange Is the New Blacks
INSERT INTO EPISODE VALUES(1,'1-AA',1,'Orange Is the New Blacks Season1',1);
INSERT INTO EPISODE VALUES(1,'1-BB',2,'Orange Is the New Blacks Season1',1);
INSERT INTO EPISODE VALUES(1,'1-CC',3,'Orange Is the New Blacks Season1',1);
INSERT INTO EPISODE VALUES(1,'1-DD',4,'Orange Is the New Blacks Season1',1);
INSERT INTO EPISODE VALUES(1,'1-EE',5,'Orange Is the New Blacks Season1',1);

--2Narcos
INSERT INTO EPISODE VALUES(2,'2-AA',1,'Narcos Season 1',1);
INSERT INTO EPISODE VALUES(2,'2-BB',2,'Narcos Season 1',1);
INSERT INTO EPISODE VALUES(2,'2-CC',3,'Narcos Season 1',1);
INSERT INTO EPISODE VALUES(2,'2-DD',1,'Narcos Season 2',2);
INSERT INTO EPISODE VALUES(2,'2-EE',2,'Narcos Season 2',2);

--3Daredevil
INSERT INTO EPISODE VALUES(3,'3-AA',1,'Daredevil Season1',1);
INSERT INTO EPISODE VALUES(3,'3-BB',2,'Daredevil Season1',1);
INSERT INTO EPISODE VALUES(3,'3-CC',3,'Daredevil Season1',1);
INSERT INTO EPISODE VALUES(3,'3-DD',4,'Daredevil Season1',1);
INSERT INTO EPISODE VALUES(3,'3-EE',5,'Daredevil Season1',1);
--4The Get Down
INSERT INTO EPISODE VALUES(4,'4-AA',1,'The Get Down Season1',1);
INSERT INTO EPISODE VALUES(4,'4-BB',2,'The Get Down Season1',1);
INSERT INTO EPISODE VALUES(4,'4-CC',3,'The Get Down Season1',1);
INSERT INTO EPISODE VALUES(4,'4-DD',4,'The Get Down Season1',1);
INSERT INTO EPISODE VALUES(4,'4-EE',5,'The Get Down Season1',1);

--5The Crown
INSERT INTO EPISODE VALUES(5,'5-AA',1,'The Crown Season1',1);
INSERT INTO EPISODE VALUES(5,'5-BB',2,'The Crown Season1',1);
INSERT INTO EPISODE VALUES(5,'5-CC',1,'The Crown Season2',2);
INSERT INTO EPISODE VALUES(5,'5-DD',2,'The Crown Season2',2);
INSERT INTO EPISODE VALUES(5,'5-EE',3,'The Crown Season2',2);

--6 Gilmore Girls: A Year in the Life
INSERT INTO EPISODE VALUES(6,'6-AA',1,'Gilmore Girls: A Year in the Life Season1',1);
INSERT INTO EPISODE VALUES(6,'6-BB',2,'Gilmore Girls: A Year in the Life Season1',1);
INSERT INTO EPISODE VALUES(6,'6-CC',3,'Gilmore Girls: A Year in the Life Season1',1);
INSERT INTO EPISODE VALUES(6,'6-DD',4,'Gilmore Girls: A Year in the Life Season1',1);
INSERT INTO EPISODE VALUES(6,'6-EE',5,'Gilmore Girls: A Year in the Life Season1',1);

--7 13 Reasons Why
INSERT INTO EPISODE VALUES(7,'7-AA',1,'13 Reasons Why Season1',1);
INSERT INTO EPISODE VALUES(7,'7-BB',2,'13 Reasons Why Season1',1);
INSERT INTO EPISODE VALUES(7,'7-CC',3,'13 Reasons Why Season1',1);
INSERT INTO EPISODE VALUES(7,'7-DD',4,'13 Reasons Why Season1',1);
INSERT INTO EPISODE VALUES(7,'7-EE',5,'13 Reasons Why Season1',1);

--8Free Rein
INSERT INTO EPISODE VALUES(8,'8-AA',1,'Free Rein Season1',1);
INSERT INTO EPISODE VALUES(8,'8-BB',2,'Free Rein Season1',1);
INSERT INTO EPISODE VALUES(8,'8-CC',3,'Free Rein Season1',1);
INSERT INTO EPISODE VALUES(8,'8-DD',4,'Free Rein Season1',1);
INSERT INTO EPISODE VALUES(8,'8-EE',5,'Free Rein Season1',1);

--9Ozark
INSERT INTO EPISODE VALUES(9,'9-AA',1,'Ozark Season1',1);
INSERT INTO EPISODE VALUES(9,'9-BB',2,'Ozark Season1',1);
INSERT INTO EPISODE VALUES(9,'9-CC',3,'Ozark Season1',1);
INSERT INTO EPISODE VALUES(9,'9-DD',4,'Ozark Season1',1);
INSERT INTO EPISODE VALUES(9,'9-EE',5,'Ozark Season1',1);

--10The Defenders
INSERT INTO EPISODE VALUES(10,'10-AAA',1,'The Defenders Season1',1);
INSERT INTO EPISODE VALUES(10,'10-BBB',2,'The Defenders Season1',1);
INSERT INTO EPISODE VALUES(10,'10-CCC',3,'The Defenders Season1',1);
INSERT INTO EPISODE VALUES(10,'10-DDD',4,'The Defenders Season1',1);
INSERT INTO EPISODE VALUES(10,'10-EEE',5,'The Defenders Season1',1);

--11Mindhunter
INSERT INTO EPISODE VALUES(11,'11-AAA',1,'Mindhunter Season1',1);
INSERT INTO EPISODE VALUES(11,'11-BBB',2,'Mindhunter Season1',1);
INSERT INTO EPISODE VALUES(11,'11-CCC',3,'Mindhunter Season1',1);
INSERT INTO EPISODE VALUES(11,'11-DDD',4,'Mindhunter Season1',1);
INSERT INTO EPISODE VALUES(11,'11-EEE',5,'Mindhunter Season1',1);

--12Greenhouse Academy
INSERT INTO EPISODE VALUES(12,'12-AAA',1,'Greenhouse Academy Season1',1);
INSERT INTO EPISODE VALUES(12,'12-BBB',2,'Greenhouse Academy Season1',1);
INSERT INTO EPISODE VALUES(12,'12-CCC',3,'Greenhouse Academy Season1',1);
INSERT INTO EPISODE VALUES(12,'12-DDD',4,'Greenhouse Academy Season1',1);
INSERT INTO EPISODE VALUES(12,'12-EEE',5,'Greenhouse Academy Season1',1);

--13The Punisher
INSERT INTO EPISODE VALUES(13,'13-AAA',1,'The Punisher Season1',1);
INSERT INTO EPISODE VALUES(13,'13-BBB',2,'The Punisher Season1',1);
INSERT INTO EPISODE VALUES(13,'13-CCC',2,'The Punisher Season1',1);
INSERT INTO EPISODE VALUES(13,'13-DDD',2,'The Punisher Season1',1);
INSERT INTO EPISODE VALUES(13,'13-EEE',2,'The Punisher Season1',1);

--14Narcos: Mexico
INSERT INTO EPISODE VALUES(14,'14-AAA',1,'Narcos: Mexico Season1',1);
INSERT INTO EPISODE VALUES(14,'14-BBB',1,'Narcos: Mexico Season1',1);
INSERT INTO EPISODE VALUES(14,'14-CCC',1,'Narcos: Mexico Season1',1);
INSERT INTO EPISODE VALUES(14,'14-DDD',1,'Narcos: Mexico Season1',1);
INSERT INTO EPISODE VALUES(14,'14-EEE',1,'Narcos: Mexico Season1',1);

--15The Ponysitters
INSERT INTO EPISODE VALUES(15,'15-AAA',1,'The Ponysitters Season1',1);
INSERT INTO EPISODE VALUES(15,'15-BBB',2,'The Ponysitters Season1',1);
INSERT INTO EPISODE VALUES(15,'15-CCC',3,'The Ponysitters Season1',1);
INSERT INTO EPISODE VALUES(15,'15-DDD',4,'The Ponysitters Season1',1);
INSERT INTO EPISODE VALUES(15,'15-EEE',5,'The Ponysitters Season1',1);

--16The Innocents!
INSERT INTO EPISODE VALUES(16,'16-AAA',1,'The Innocents Season1',1);
INSERT INTO EPISODE VALUES(16,'16-BBB',2,'The Innocents Season1',1);
INSERT INTO EPISODE VALUES(16,'16-CCC',1,'The Innocents Season2',2);
INSERT INTO EPISODE VALUES(16,'16-DDD',2,'The Innocents Season2',2);
INSERT INTO EPISODE VALUES(16,'16-EEE',3,'The Innocents Season2',2);

--17Tidelands
INSERT INTO EPISODE VALUES(17,'17-AAA',1,'Tidelands Season1',1);
INSERT INTO EPISODE VALUES(17,'17-BBB',2,'Tidelands Season1',1);
INSERT INTO EPISODE VALUES(17,'17-CCC',3,'Tidelands Season1',1);
INSERT INTO EPISODE VALUES(17,'17-DDD',4,'Tidelands Season1',1);
INSERT INTO EPISODE VALUES(17,'17-EEE',5,'Tidelands Season1',1);

--18The Order
INSERT INTO EPISODE VALUES(18,'18-AAA',1,'The Order Season1',1);
INSERT INTO EPISODE VALUES(18,'18-BBB',2,'The Order Season1',1);
INSERT INTO EPISODE VALUES(18,'18-CCC',3,'The Order Season1',1);
INSERT INTO EPISODE VALUES(18,'18-DDD',1,'The Order Season2',2);
INSERT INTO EPISODE VALUES(18,'18-EEE',2,'The Order Season2',2);
INSERT INTO EPISODE VALUES(18,'18-FFF',3,'The Order Season2',2);

--19Black Summer
INSERT INTO EPISODE VALUES(19,'19-AAA',1,'Black Summer Season1',1);
INSERT INTO EPISODE VALUES(19,'19-BBB',2,'Black Summer Season1',1);
INSERT INTO EPISODE VALUES(19,'19-CCC',1,'Black Summer Season2',2);
INSERT INTO EPISODE VALUES(19,'19-DDD',2,'Black Summer Season2',2);
INSERT INTO EPISODE VALUES(19,'19-EEE',1,'Black Summer Season3',3);
INSERT INTO EPISODE VALUES(19,'19-FFF',2,'Black Summer Season3',3);
INSERT INTO EPISODE VALUES(19,'19-GGG',1,'Black Summer Season4',4);
INSERT INTO EPISODE VALUES(19,'19-HHH',2,'Black Summer Season4',4);
INSERT INTO EPISODE VALUES(19,'19-III',3,'Black Summer Season4',4);
INSERT INTO EPISODE VALUES(19,'19-JJJ',4,'Black Summer Season4',4);